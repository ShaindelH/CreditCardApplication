package finalProject;

public enum TransactionType {PURCHASE, PAYMENT, FEE}
	

