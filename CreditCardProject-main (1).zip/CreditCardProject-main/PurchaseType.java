package finalProject;

public enum PurchaseType { CAR, CLOTHING, FOOD, GROCERIES, LODGING, RESTAURANT, TRAVEL, UTILITES}
