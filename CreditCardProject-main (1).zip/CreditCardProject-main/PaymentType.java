package finalProject;

public enum PaymentType {CHECK, ONLINE}
