package finalProject;

public enum CreditCardType { VISA, MASTERCARD, AMEX }
