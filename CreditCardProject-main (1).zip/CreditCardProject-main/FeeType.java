package finalProject;

public enum FeeType {LatePayment, Interest}
