package finalProject;

public enum CreditCardStatus {ACTIVE, CANCELLED, LOST, EXPIRED}
